
package quintopunto;


public class codigo5 {
    public static void main(String[] args) {
        int manzana=52;
        int piña=55;
        int pera=55;
        int naranja=45;
        int fresas=32;
        int melon=54;
        int caloriastotales=(2*manzana)+(3*pera)+(1*naranja)+(1*melon);
        System.out.println("El total de calorias consumido fue: "+caloriastotales+" Kcal");
        
    }
}
